﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POLICLINICA
{

    public partial class Form6 : Form
    {
        private int visitId;
        private int patientId;
        private string connectionString;
        private DateTime visitDate; // Сохраняем дату визита

        public Form6()
        {
            InitializeComponent();
        }

        // Конструктор с параметрами
        public Form6(int visitId, int patientId, string patientName, DateTime visitDateTime, string connectionString) : this()
        {
            this.visitId = visitId;
            this.patientId = patientId;
            this.connectionString = connectionString;
            this.visitDate = visitDateTime.Date; // Сохраняем только дату

            // Отображаем информацию о пациенте
            label1.Text = $"Пациент: {patientName}";

            // Дополнительно показываем дату визита для информации
            label3.Text = $"Дата визита: {visitDateTime:dd.MM.yyyy}";
            label3.Visible = true;
        }

        // Кнопка "Добавить"
        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Введите содержание больничного листа!", "Ошибка");
                return;
            }

            try
            {
                AddSickLeaveToDatabase();
                MessageBox.Show("Больничный лист успешно добавлен!", "Успех");
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении: " + ex.Message, "Ошибка");
            }
        }

        // Кнопка "Отмена"
        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void AddSickLeaveToDatabase()
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();

                string insertSql = @"
                    INSERT INTO myschema.sick_leaves 
                        (issue_date, status, content, patient_id, visit_id)
                    VALUES 
                        (@issue_date, 'открыт', @content, @patient_id, @visit_id)";

                using (var cmd = new NpgsqlCommand(insertSql, conn))
                {
                    // Используем дату визита для issue_date
                    cmd.Parameters.AddWithValue("@issue_date", visitDate);
                    cmd.Parameters.AddWithValue("@content", textBox1.Text);
                    cmd.Parameters.AddWithValue("@patient_id", patientId);
                    cmd.Parameters.AddWithValue("@visit_id", visitId);

                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
