﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace POLICLINICA
{
    public partial class Form4 : Form
    {
        private string connectionString = "Host=localhost;Database=polyclinic;Username=postgres;Password=1234;";

        private string connString;
        private string doctorName;
        private DateTime workDate;
        private TimeSpan time;
        public int SelectedPatientId { get; private set; }

        public Form4(string doctorName, DateTime workDate, TimeSpan time, string connString)
        {
            InitializeComponent();

            label1.Text = "Добавление визита";
            label2.Text = "Врач: " + doctorName;
            label3.Text = $"Дата и время: {workDate.ToShortDateString()} {time}";

            this.connString = connString;
            SelectedPatientId = -1;

            LoadPatients();
        }

        private void LoadPatients()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string sql = "SELECT patient_id, last_name || ' ' || first_name as full_name FROM myschema.patients ORDER BY last_name";
                    var cmd = new NpgsqlCommand(sql, conn);
                    var reader = cmd.ExecuteReader();

                    comboBox1.Items.Clear();
                    while (reader.Read())
                    {
                        comboBox1.Items.Add(new
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1)
                        });
                    }
                    reader.Close();

                    comboBox1.DisplayMember = "Name";
                    comboBox1.ValueMember = "Id";

                    if (comboBox1.Items.Count > 0)
                        comboBox1.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки пациентов: " + ex.Message);
            }
        }

        // Обработчик для существующей кнопки button1 ("Добавить")
        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Выберите пациента!");
                return;
            }

            dynamic patient = comboBox1.SelectedItem;
            SelectedPatientId = patient.Id;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        // Обработчик для существующей кнопки button2 ("Отмена")
        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
