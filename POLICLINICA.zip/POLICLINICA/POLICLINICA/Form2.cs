﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POLICLINICA
{
    public partial class Form2 : Form
    {
        private string connectionString = "Host=localhost;Database=polyclinic;Username=postgres;Password=1234;";

        public Form2()
        {
            InitializeComponent();
            comboBox1.Items.AddRange(new string[] { "admin", "doctor" });
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text.Trim();
            string password = textBox2.Text;
            string userType = comboBox1.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Введите логин и пароль", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                if (userType == "admin")
                {
                    CheckAdminLogin(login, password);
                }
                else if (userType == "doctor")
                {
                    CheckDoctorLogin(login, password);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CheckAdminLogin(string login, string password)
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();

                string query = "SELECT admin_id FROM myschema.role_administrator " +
                              "WHERE login = @login AND password = crypt(@password, password)";

                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@login", login);
                    cmd.Parameters.AddWithValue("@password", password);

                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        int adminId = Convert.ToInt32(result);
                        MessageBox.Show($"Успешный вход! ID: {adminId}", "Успех");

                        Form3 form3 = new Form3();
                        this.Hide();
                        form3.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль", "Ошибка");
                    }
                }
            }
        }

        private void CheckDoctorLogin(string login, string password)
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();

                string query = "SELECT doctor_id FROM myschema.role_doctor " +
                              "WHERE login = @login AND password = crypt(@password, password)";

                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@login", login);
                    cmd.Parameters.AddWithValue("@password", password);

                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        int doctorId = Convert.ToInt32(result);
                        MessageBox.Show($"Успешный вход! ID: {doctorId}", "Успех");

                        // Открываем Form5 для врача
                        Form5 doctorForm = new Form5(doctorId, connectionString);
                        this.Hide();
                        doctorForm.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль", "Ошибка");
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
