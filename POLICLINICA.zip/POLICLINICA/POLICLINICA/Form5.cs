﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POLICLINICA
{
    public partial class Form5 : Form
    {
        private int doctorId;
        private string connectionString;
        private string doctorFullName;

        public Form5(int doctorId, string connectionString)
        {
            InitializeComponent();
            this.doctorId = doctorId;
            this.connectionString = connectionString;

            LoadDoctorInfo();
            LoadDoctorVisits();
            LoadSickLeaves();
            LoadDiagnoses();

            
        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Просто для отладки
            if (e.RowIndex >= 0)
            {
                var row = dataGridView1.Rows[e.RowIndex];
                Console.WriteLine($"Клик по строке {e.RowIndex}, столбцу {e.ColumnIndex}");
            }
        }

        private void LoadDoctorInfo()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    string sql = @"SELECT last_name, first_name, patronymic 
                                  FROM myschema.doctors WHERE doctor_id = @doctor_id";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@doctor_id", doctorId);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string lastName = reader.GetString(0);
                                string firstName = reader.GetString(1);
                                string patronymic = reader.IsDBNull(2) ? "" : reader.GetString(2);

                                doctorFullName = $"{lastName} {firstName} {patronymic}";
                                label1.Text = $"Добро пожаловать, {doctorFullName}!";
                                this.Text = $"Врач: {doctorFullName}";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных врача: " + ex.Message);
            }
        }

        private void LoadDoctorVisits()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    // Загружаем визиты для данного врача
                    string sql = @"
                        SELECT 
                            p.last_name || ' ' || p.first_name as Пациент,
                            v.visit_date_time as ""Дата и время"",
                            v.status as Статус,
                            v.visit_id,
                            v.schedule_id,
                            v.patient_id
                        FROM myschema.visits v
                        JOIN myschema.schedule s ON v.schedule_id = s.schedule_id
                        JOIN myschema.patients p ON v.patient_id = p.patient_id
                        WHERE s.doctor_id = @doctor_id
                        ORDER BY v.visit_date_time";

                    var adapter = new NpgsqlDataAdapter(sql, conn);
                    adapter.SelectCommand.Parameters.AddWithValue("@doctor_id", doctorId);

                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    // Отладочная информация о колонках
                    Console.WriteLine("Колонки в DataTable:");
                    foreach (DataColumn column in dt.Columns)
                    {
                        Console.WriteLine($"- {column.ColumnName} (тип: {column.DataType})");
                    }

                    dataGridView1.DataSource = dt;
                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    // Скрываем все ID столбцы
                    string[] hiddenColumns = { "visit_id", "schedule_id", "patient_id" };
                    foreach (string colName in hiddenColumns)
                    {
                        if (dataGridView1.Columns.Contains(colName))
                        {
                            dataGridView1.Columns[colName].Visible = false;
                            Console.WriteLine($"Скрыт столбец: {colName}");
                        }
                        else
                        {
                            Console.WriteLine($"Столбец {colName} не найден в DataGridView!");
                        }
                    }

                    // Также проверим все столбцы в DataGridView
                    Console.WriteLine("Столбцы в DataGridView:");
                    foreach (DataGridViewColumn col in dataGridView1.Columns)
                    {
                        Console.WriteLine($"- {col.Name} (Visible: {col.Visible})");
                    }

                    label2.Text = $"Всего визитов: {dt.Rows.Count}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки визитов: " + ex.Message);
            }
        }

        // Кнопка для изменения статуса на "Осуществлен"
        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите визит для изменения статуса!");
                return;
            }

            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            int visitId = Convert.ToInt32(selectedRow.Cells["visit_id"].Value);
            string patientName = selectedRow.Cells["Пациент"].Value.ToString();
            string currentStatus = selectedRow.Cells["Статус"].Value.ToString();

            if (currentStatus == "Осуществлен")
            {
                MessageBox.Show("Этот визит уже осуществлен!");
                return;
            }

            DialogResult result = MessageBox.Show(
                $"Изменить статус визита для пациента {patientName} на 'Осуществлен'?",
                "Подтверждение",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                UpdateVisitStatus(visitId, "Осуществлен");
            }
        }

        // Кнопка для изменения статуса на "Отменен"
        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите визит для изменения статуса!");
                return;
            }

            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            int visitId = Convert.ToInt32(selectedRow.Cells["visit_id"].Value);
            string patientName = selectedRow.Cells["Пациент"].Value.ToString();
            string currentStatus = selectedRow.Cells["Статус"].Value.ToString();

            if (currentStatus == "Отменен")
            {
                MessageBox.Show("Этот визит уже отменен!");
                return;
            }

            DialogResult result = MessageBox.Show(
                $"Изменить статус визита для пациента {patientName} на 'Отменен'?",
                "Подтверждение",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                UpdateVisitStatus(visitId, "Отменен");
            }
        }

        private void UpdateVisitStatus(int visitId, string newStatus)
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = "UPDATE myschema.visits SET status = @status WHERE visit_id = @visit_id";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@status", newStatus);
                        cmd.Parameters.AddWithValue("@visit_id", visitId);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show($"Статус визита изменен на '{newStatus}'!", "Успех");
                            LoadDoctorVisits(); // Обновляем таблицу
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка обновления статуса: " + ex.Message);
            }
        }

        // Кнопка для обновления данных
        private void button3_Click(object sender, EventArgs e)
        {
            LoadDoctorVisits();
            LoadSickLeaves();
            LoadDiagnoses();
            MessageBox.Show("Все данные обновлены!");
        }

        // Кнопка выхода
        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Обработчик двойного клика по строке
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            // Проверяем, что клик не по заголовку
            if (e.RowIndex < 0 || e.ColumnIndex < 0)
                return;

            try
            {
                // Получаем выбранную строку
                var selectedRow = dataGridView1.Rows[e.RowIndex];

                // Получаем ID визита
                int visitId = Convert.ToInt32(selectedRow.Cells["visit_id"].Value);

                // Получаем информацию о пациенте
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"
                SELECT 
                    p.last_name,
                    p.first_name,
                    p.patronymic,
                    p.birth_date,
                    p.address
                FROM myschema.visits v
                JOIN myschema.patients p ON v.patient_id = p.patient_id
                WHERE v.visit_id = @visit_id";

                    var cmd = new NpgsqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@visit_id", visitId);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string lastName = reader["last_name"].ToString();
                            string firstName = reader["first_name"].ToString();
                            string patronymic = reader["patronymic"]?.ToString() ?? "Не указано";
                            DateTime birthDate = Convert.ToDateTime(reader["birth_date"]);
                            string address = reader["address"].ToString();

                            string message = $"Пациент: {lastName} {firstName} {patronymic}\n" +
                                            $"Дата рождения: {birthDate.ToShortDateString()}\n" +
                                            $"Адрес: {address}";

                            MessageBox.Show(message, "Информация о пациенте");
                        }
                        else
                        {
                            MessageBox.Show("Пациент не найден для данного визита", "Информация");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при получении данных: {ex.Message}", "Ошибка");
            }

        }



        /// 
        private void LoadSickLeaves()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"
                        SELECT 
                            sl.issue_date as ""Дата выдачи"",
                            sl.status as ""Статус"",
                            sl.content as ""Содержание"",
                            p.last_name || ' ' || p.first_name as ""Пациент"",
                            v.visit_date_time as ""Дата визита""
                        FROM myschema.sick_leaves sl
                        JOIN myschema.visits v ON sl.visit_id = v.visit_id
                        JOIN myschema.schedule s ON v.schedule_id = s.schedule_id
                        JOIN myschema.patients p ON sl.patient_id = p.patient_id
                        WHERE s.doctor_id = @doctor_id
                        ORDER BY sl.issue_date DESC";

                    var adapter = new NpgsqlDataAdapter(sql, conn);
                    adapter.SelectCommand.Parameters.AddWithValue("@doctor_id", doctorId);

                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dataGridView2.DataSource = dt;
                    dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    label3.Text = $"Больничных листов: {dt.Rows.Count}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки больничных листов: " + ex.Message);
            }
        }

       

        // закрыть больничный лист
        private void button5_Click(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите больничный лист для изменения статуса!");
                return;
            }

            DataGridViewRow selectedRow = dataGridView2.SelectedRows[0];
            string patientName = selectedRow.Cells["Пациент"].Value.ToString();
            string currentStatus = selectedRow.Cells["Статус"].Value.ToString();
            DateTime issueDate = Convert.ToDateTime(selectedRow.Cells["Дата выдачи"].Value);
            DateTime visitDate = Convert.ToDateTime(selectedRow.Cells["Дата визита"].Value);

            if (currentStatus.ToLower() == "закрыт")
            {
                MessageBox.Show("Этот больничный лист уже закрыт!");
                return;
            }

            DialogResult result = MessageBox.Show(
                $"Изменить статус больничного листа для пациента {patientName} на 'закрыт'?",
                "Подтверждение",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                UpdateSickLeaveStatus(issueDate, patientName, visitDate);
            }
        }

        private void UpdateSickLeaveStatus(DateTime issueDate, string patientName, DateTime visitDate)
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string updateSql = @"
                        UPDATE myschema.sick_leaves sl
                        SET status = 'закрыт'
                        FROM myschema.visits v
                        JOIN myschema.schedule s ON v.schedule_id = s.schedule_id
                        JOIN myschema.patients p ON v.patient_id = p.patient_id
                        WHERE sl.visit_id = v.visit_id
                          AND s.doctor_id = @doctor_id
                          AND p.last_name || ' ' || p.first_name = @patient_name
                          AND sl.issue_date = @issue_date
                          AND v.visit_date_time = @visit_date";

                    using (var cmd = new NpgsqlCommand(updateSql, conn))
                    {
                        cmd.Parameters.AddWithValue("@doctor_id", doctorId);
                        cmd.Parameters.AddWithValue("@patient_name", patientName);
                        cmd.Parameters.AddWithValue("@issue_date", issueDate);
                        cmd.Parameters.AddWithValue("@visit_date", visitDate);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Статус больничного листа изменен на 'закрыт'!");
                            LoadSickLeaves();
                        }
                        else
                        {
                            MessageBox.Show("Не удалось изменить статус больничного листа");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка обновления статуса: " + ex.Message);
            }
        }

        // добавить больничный лист 
        private void button6_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Сначала выберите визит в таблице визитов для создания больничного листа!", "Ошибка");
                return;
            }

            try
            {
                DataGridViewRow selectedVisitRow = dataGridView1.SelectedRows[0];
                int visitId = Convert.ToInt32(selectedVisitRow.Cells["visit_id"].Value);
                int patientId = Convert.ToInt32(selectedVisitRow.Cells["patient_id"].Value);
                string patientName = selectedVisitRow.Cells["Пациент"].Value.ToString();
                DateTime visitDateTime = Convert.ToDateTime(selectedVisitRow.Cells["Дата и время"].Value);

                // Открываем новую форму для добавления больничного листа
                Form6 addForm = new Form6(visitId, patientId, patientName, visitDateTime, connectionString);

                if (addForm.ShowDialog() == DialogResult.OK)
                {
                    MessageBox.Show("Больничный лист успешно добавлен!");
                    LoadSickLeaves(); // Обновляем таблицу
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }


        private void LoadDiagnoses()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"
                SELECT 
                    d.mkb_code as ""Код МКБ"",
                    d.description as ""Описание"",
                    p.last_name || ' ' || p.first_name as ""Пациент"",
                    sl.issue_date as ""Дата больничного""
                FROM myschema.diagnoses d
                JOIN myschema.sick_leaves sl ON d.sick_leave_id = sl.sick_leave_id
                JOIN myschema.patients p ON sl.patient_id = p.patient_id
                JOIN myschema.visits v ON sl.visit_id = v.visit_id
                JOIN myschema.schedule s ON v.schedule_id = s.schedule_id
                WHERE s.doctor_id = @doctor_id
                ORDER BY sl.issue_date DESC";

                    var adapter = new NpgsqlDataAdapter(sql, conn);
                    adapter.SelectCommand.Parameters.AddWithValue("@doctor_id", doctorId);

                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dataGridView3.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки диагнозов: " + ex.Message);
            }
        }

        private int GetSickLeaveIdFromRow(DataGridViewRow row)
        {
            try
            {
                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();

                    string patientName = row.Cells["Пациент"].Value.ToString();
                    DateTime issueDate = Convert.ToDateTime(row.Cells["Дата выдачи"].Value);
                    DateTime visitDate = Convert.ToDateTime(row.Cells["Дата визита"].Value);

                    string sql = @"
                SELECT sl.sick_leave_id
                FROM myschema.sick_leaves sl
                JOIN myschema.visits v ON sl.visit_id = v.visit_id
                JOIN myschema.schedule s ON v.schedule_id = s.schedule_id
                JOIN myschema.patients p ON sl.patient_id = p.patient_id
                WHERE s.doctor_id = @doctor_id
                  AND p.last_name || ' ' || p.first_name = @patient_name
                  AND sl.issue_date = @issue_date
                  AND v.visit_date_time = @visit_date";

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@doctor_id", doctorId);
                        cmd.Parameters.AddWithValue("@patient_name", patientName);
                        cmd.Parameters.AddWithValue("@issue_date", issueDate);
                        cmd.Parameters.AddWithValue("@visit_date", visitDate);

                        object result = cmd.ExecuteScalar();

                        if (result == null || result == DBNull.Value)
                        {
                            throw new Exception("Не удалось найти ID больничного листа для выбранной записи.");
                        }

                        return Convert.ToInt32(result);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка получения ID больничного листа: {ex.Message}");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count == 0)
            {
                MessageBox.Show("Сначала выберите больничный лист в таблице больничных листов для добавления диагноза!", "Ошибка");
                return;
            }

            try
            {
                DataGridViewRow selectedSickLeaveRow = dataGridView2.SelectedRows[0];
                int sickLeaveId = GetSickLeaveIdFromRow(selectedSickLeaveRow);
                string patientName = selectedSickLeaveRow.Cells["Пациент"].Value.ToString();

                // Открываем новую форму для добавления диагноза
                Form7 addForm = new Form7(sickLeaveId, patientName, connectionString);

                addForm.ShowDialog();
                
                LoadDiagnoses();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        // Метод для удаления диагноза
        private void DeleteDiagnosis()
        {
            DataGridViewRow row = dataGridView3.SelectedRows[0];

            string mkbCode = row.Cells["Код МКБ"].Value.ToString();
            string description = row.Cells["Описание"].Value.ToString();
            string patientName = row.Cells["Пациент"].Value.ToString();
            DateTime sickLeaveDate = Convert.ToDateTime(row.Cells["Дата больничного"].Value);

            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();

                string deleteSql = @"
            DELETE FROM myschema.diagnoses d
            WHERE d.diagnosis_id IN (
                SELECT d2.diagnosis_id
                FROM myschema.diagnoses d2
                JOIN myschema.sick_leaves sl ON d2.sick_leave_id = sl.sick_leave_id
                JOIN myschema.patients p ON sl.patient_id = p.patient_id
                JOIN myschema.visits v ON sl.visit_id = v.visit_id
                JOIN myschema.schedule s ON v.schedule_id = s.schedule_id
                WHERE s.doctor_id = @doctor_id
                  AND p.last_name || ' ' || p.first_name = @patient_name
                  AND d2.mkb_code = @mkb_code
                  AND d2.description = @description
                  AND sl.issue_date = @issue_date
            )";

                using (var cmd = new NpgsqlCommand(deleteSql, conn))
                {
                    cmd.Parameters.AddWithValue("@doctor_id", doctorId);
                    cmd.Parameters.AddWithValue("@patient_name", patientName);
                    cmd.Parameters.AddWithValue("@mkb_code", mkbCode);
                    cmd.Parameters.AddWithValue("@description", description);
                    cmd.Parameters.AddWithValue("@issue_date", sickLeaveDate.Date);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (dataGridView3.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите диагноз!");
                return;
            }

            // Простое подтверждение
            if (MessageBox.Show("Удалить выбранный диагноз?", "Удаление",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    DeleteDiagnosis();
                    LoadDiagnoses();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                }
            }
        }
    }

}