﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NpgsqlTypes;

namespace POLICLINICA
{
    public partial class Form3 : Form
    {
        string connString = "Host=localhost;Database=polyclinic;Username=postgres;Password=1234;";
        private DataTable allData;
        // Для хранения выбранного врача при добавлении
        private string selectedDoctorForAdd = "";
        private int selectedDoctorId = -1;

        //
        private bool isSelectingSlotForVisit = false;
        private int selectedScheduleId = -1;
        private int selectedDoctorIdFromSchedule = -1;
        private DateTime selectedWorkDate;
        private TimeSpan selectedTime;
        private string selectedDoctorName = "";
        //

       

        public Form3()
        {
            InitializeComponent();
            LoadData();
            LoadComboBoxData();
            //LoadDoctorsForReport();
            LoadDoctorsToComboBox(comboBox3, false); // без "Все врачи"
            LoadDoctorsToComboBox(comboBox5, true);  // с "Все врачи"
            LoadVisitsData();
            LoadDoctorsData();
            LoadPatientsData();
            LoadAdministratorsData();

            // Добавляем элементы в comboBox4
            comboBox4.Items.Add("Пациент");
            comboBox4.Items.Add("Врач");
            comboBox4.Items.Add("Администратор");

            // Устанавливаем первый элемент выбранным по умолчанию
            if (comboBox4.Items.Count > 0)
                comboBox4.SelectedIndex = 0;

            // Прячем поля для врача при запуске
            textBox5.Visible = false;
            numericUpDown1.Visible = false;

            // Добавляем загрузку статистики диагнозов
            LoadDiagnosesStatistics();
        }

        // Метод загрузки данных
        void LoadData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    string sql = @"
                        SELECT 
                            s.schedule_id as ID,
                            d.last_name || ' ' || d.first_name as Врач,
                            s.work_date as Дата,
                            s.time as Время,
                            CASE 
                                WHEN s.is_available = true THEN 'Свободен'
                                ELSE 'Занят'
                            END as Статус
                        FROM myschema.schedule s
                        JOIN myschema.doctors d ON s.doctor_id = d.doctor_id
                        ORDER BY Врач, Дата, Время";

                    var adapter = new NpgsqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    allData = dt.Copy();
                    dataGridView1.DataSource = dt;
                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    label2.Text = $"Всего записей: {dt.Rows.Count}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        // Кнопка 1 - Все врачи
        private void button1_Click(object sender, EventArgs e)
        {
            if (allData != null)
            {
                dataGridView1.DataSource = allData;
                label2.Text = $"Всего записей: {allData.Rows.Count}";
            }
        }

        private void button2_Click(object sender, EventArgs e) {FilterData("Быков Андрей");}
        private void button3_Click(object sender, EventArgs e) {FilterData("Ерошкина Анна");}
        private void button4_Click(object sender, EventArgs e) {FilterData("Смирнова Ольга");}
        private void button5_Click(object sender, EventArgs e) {FilterData("Смирнов Ярослав");}
        private void button6_Click(object sender, EventArgs e) {FilterData("Кузнецов Андрей");}
        private void button7_Click(object sender, EventArgs e) {FilterData("Петрова Мария");}
        private void button8_Click(object sender, EventArgs e) {FilterData("Лобанов Семён");}
        private void button9_Click(object sender, EventArgs e) {FilterData("Елисеева Марианна");}
        private void button10_Click(object sender, EventArgs e){FilterData("Романова Антонина");}

        // Метод фильтрации
        private void FilterData(string doctorName)
        {
            if (allData == null)
            {
                MessageBox.Show("Нет данных для фильтрации");
                return;
            }

            try
            {
                DataTable filtered = new DataTable();
                filtered = allData.Clone();
                int count = 0;

                foreach (DataRow row in allData.Rows)
                {
                    if (row["Врач"].ToString() == doctorName)
                    {
                        filtered.ImportRow(row);
                        count++;
                    }
                }

                dataGridView1.DataSource = filtered;
                label2.Text = $"{doctorName} ({count} записей)";
                this.Text = $"{doctorName} ({count})";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка фильтрации: " + ex.Message);
            }
        }

        // Button11 - Обновить данные
        private void button11_Click(object sender, EventArgs e)
        {
            LoadData();
            MessageBox.Show("Данные обновлены", "Информация",
                          MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Метод для загрузки данных в ComboBox
        private void LoadComboBoxData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    // Загружаем врачей в comboBox1
                    string doctorsSql = "SELECT doctor_id, last_name || ' ' || first_name as full_name FROM myschema.doctors ORDER BY last_name";
                    var doctorsCmd = new NpgsqlCommand(doctorsSql, conn);
                    var reader = doctorsCmd.ExecuteReader();

                    comboBox1.Items.Clear();
                    while (reader.Read())
                    {
                        comboBox1.Items.Add(new
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1)
                        });
                    }
                    reader.Close();

                    comboBox1.DisplayMember = "Name";
                    comboBox1.ValueMember = "Id";

                    // Выбираем первый элемент
                    if (comboBox1.Items.Count > 0)
                        comboBox1.SelectedIndex = 0;

                    // Загружаем администраторов в comboBox2
                    string adminsSql = "SELECT admin_id, last_name || ' ' || first_name as full_name FROM myschema.administrators ORDER BY last_name";
                    var adminsCmd = new NpgsqlCommand(adminsSql, conn);
                    reader = adminsCmd.ExecuteReader();

                    comboBox2.Items.Clear();
                    while (reader.Read())
                    {
                        comboBox2.Items.Add(new
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1)
                        });
                    }
                    reader.Close();

                    comboBox2.DisplayMember = "Name";
                    comboBox2.ValueMember = "Id";

                    // Выбираем первый элемент
                    if (comboBox2.Items.Count > 0)
                        comboBox2.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        // Button12 - Добавить слот
        private void button12_Click(object sender, EventArgs e)
        {    // Проверяем, что выбраны врач и администратор
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Выберите врача!", "Ошибка");
                return;
            }

            if (comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Выберите администратора!", "Ошибка");
                return;
            }

            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    // ID выбранного врача
                    dynamic doctor = comboBox1.SelectedItem;
                    int doctorId = doctor.Id;

                    // ID выбранного администратора
                    dynamic admin = comboBox2.SelectedItem;
                    int adminId = admin.Id;

                    // Получаем дату и время
                    DateTime workDate = dateTimePicker1.Value.Date;
                    TimeSpan time = dateTimePicker2.Value.TimeOfDay;

                    // Получаем статус
                    bool isAvailable = checkBox1.Checked;

                    if (selectedDoctorId == -1)
                    {
                        // ДОБАВЛЯЕМ новую запись
                        string insertSql = @"
                    INSERT INTO myschema.schedule 
                        (doctor_id, admin_id, work_date, time, is_available)
                    VALUES 
                        (@doctor_id, @admin_id, @work_date, @time, @is_available)";

                        var cmd = new NpgsqlCommand(insertSql, conn);
                        cmd.Parameters.AddWithValue("@doctor_id", doctorId);
                        cmd.Parameters.AddWithValue("@admin_id", adminId);
                        cmd.Parameters.AddWithValue("@work_date", workDate);
                        cmd.Parameters.AddWithValue("@time", time);
                        cmd.Parameters.AddWithValue("@is_available", isAvailable);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Слот добавлен!", "Успех");
                    }
                    else
                    {
                        // ОБНОВЛЯЕМ существующую запись
                        string updateSql = @"
                    UPDATE myschema.schedule 
                    SET doctor_id = @doctor_id, 
                        admin_id = @admin_id, 
                        work_date = @work_date, 
                        time = @time, 
                        is_available = @is_available
                    WHERE schedule_id = @schedule_id";

                        var cmd = new NpgsqlCommand(updateSql, conn);
                        cmd.Parameters.AddWithValue("@doctor_id", doctorId);
                        cmd.Parameters.AddWithValue("@admin_id", adminId);
                        cmd.Parameters.AddWithValue("@work_date", workDate);
                        cmd.Parameters.AddWithValue("@time", time);
                        cmd.Parameters.AddWithValue("@is_available", isAvailable);
                        cmd.Parameters.AddWithValue("@schedule_id", selectedDoctorId);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Слот обновлен!", "Успех");
                    }

                    LoadData(); // Обновляем таблицу

                    // Очищаем поля для следующего добавления
                    dateTimePicker1.Value = DateTime.Today;
                    dateTimePicker2.Value = DateTime.Today.AddHours(9);
                    checkBox1.Checked = true;

                    // Сбрасываем ID редактирования
                    selectedDoctorId = -1;
                }
            }
            catch (PostgresException ex)
            {
                if (ex.SqlState == "23505") // Ошибка уникальности (дубликат)
                {
                    MessageBox.Show("Такой слот уже существует для этого врача на указанные дату и время!", "Ошибка");
                }
                else
                {
                    MessageBox.Show("Ошибка базы данных: " + ex.MessageText, "Ошибка");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка");
            }
        }

        // Button13 - Удалить слот
        private void button13_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите слот для удаления", "Информация",
                               MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            int scheduleId = Convert.ToInt32(selectedRow.Cells["ID"].Value);
            string doctorName = selectedRow.Cells["Врач"].Value.ToString();
            string workDate = Convert.ToDateTime(selectedRow.Cells["Дата"].Value).ToShortDateString();
            string time = selectedRow.Cells["Время"].Value.ToString();
            string status = selectedRow.Cells["Статус"].Value.ToString();

            // Подтверждение удаления
            DialogResult result = MessageBox.Show(
                $"Вы уверены, что хотите удалить слот расписания?\n" +
                $"Врач: {doctorName}\n" +
                $"Дата: {workDate}\n" +
                $"Время: {time}\n" +
                $"Статус: {status}\n\n" +
                "Если есть связанные визиты, слот будет помечен как 'Занят'.",
                "Подтверждение удаления",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result != DialogResult.Yes)
                return;

            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    string deleteSql = "DELETE FROM myschema.schedule WHERE schedule_id = @id";
                    string checkSql = "SELECT is_available, time FROM myschema.schedule WHERE schedule_id = @id";

                    int rowsAffected = 0;

                    // Выполняем удаление
                    using (var deleteCmd = new NpgsqlCommand(deleteSql, conn))
                    {
                        deleteCmd.Parameters.AddWithValue("@id", scheduleId);
                        rowsAffected = deleteCmd.ExecuteNonQuery();
                    }

                    // Анализируем результат
                    string message = "";
                    bool isSuccess = false;

                    if (rowsAffected == 1)
                    {
                        // Слот удален полностью
                        message = "Слот расписания успешно удален полностью!";
                        isSuccess = true;
                    }
                    else // rowsAffected == 0 - значит сработал триггер
                    {
                        // Проверяем, что осталось в базе
                        using (var checkCmd = new NpgsqlCommand(checkSql, conn))
                        {
                            checkCmd.Parameters.AddWithValue("@id", scheduleId);
                            using (var reader = checkCmd.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    bool isAvailable = reader.GetBoolean(0);
                                    string newTime = reader.GetTimeSpan(1).ToString();

                                    if (!isAvailable)
                                    {
                                        message = "Слот не может быть удален, так как есть связанные визиты.\n" +
                                                 "Слот помечен как 'Занят'.";
                                        isSuccess = true;
                                    }
                                    else
                                    {
                                        message = "Слот не был удален по неизвестной причине.";
                                    }
                                }
                                else
                                {
                                    message = "Слот не найден в базе данных.";
                                    isSuccess = true;
                                }
                            }
                        }
                    }

                    // Показываем результат
                    MessageBox.Show(message, isSuccess ? "Информация" : "Внимание",
                                  MessageBoxButtons.OK,
                                  isSuccess ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

                    // Обновляем таблицу расписания
                    LoadData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            // Очищаем поля
            if (comboBox1.Items.Count > 0)
                comboBox1.SelectedIndex = 0;

            if (comboBox2.Items.Count > 0)
                comboBox2.SelectedIndex = 0;

            dateTimePicker1.Value = DateTime.Today;
            dateTimePicker2.Value = DateTime.Today.AddHours(9);
            checkBox1.Checked = true;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите запись для редактирования");
                return;
            }

            // Просто заполняем поля выбранной записью
            DataGridViewRow row = dataGridView1.SelectedRows[0];

            // Находим врача в comboBox1
            string doctorName = row.Cells["Врач"].Value.ToString();
            for (int i = 0; i < comboBox1.Items.Count; i++)
            {
                dynamic item = comboBox1.Items[i];
                if (item.Name == doctorName)
                {
                    comboBox1.SelectedIndex = i;
                    break;
                }
            }

            // Устанавливаем дату
            dateTimePicker1.Value = Convert.ToDateTime(row.Cells["Дата"].Value);

            // Устанавливаем время
            string timeStr = row.Cells["Время"].Value.ToString();
            dateTimePicker2.Value = DateTime.Parse("2000-01-01 " + timeStr);

            // Устанавливаем статус
            checkBox1.Checked = (row.Cells["Статус"].Value.ToString() == "Свободен");

            // Сохраняем ID для обновления
            selectedDoctorId = Convert.ToInt32(row.Cells["ID"].Value);
            // Сбрасываем ID редактирования
        }


        //// Метод для загрузки врачей в comboBox3
        //private void LoadDoctorsForReport()
        //{
        //    try
        //    {
        //        using (var conn = new NpgsqlConnection(connString))
        //        {
        //            conn.Open();
        //            string sql = "SELECT doctor_id, last_name || ' ' || first_name as full_name FROM myschema.doctors ORDER BY last_name";
        //            var cmd = new NpgsqlCommand(sql, conn);
        //            var reader = cmd.ExecuteReader();

        //            comboBox3.Items.Clear();
        //            while (reader.Read())
        //            {
        //                comboBox3.Items.Add(new
        //                {
        //                    Id = reader.GetInt32(0),
        //                    Name = reader.GetString(1)
        //                });
        //            }
        //            reader.Close();

        //            comboBox3.DisplayMember = "Name";
        //            comboBox3.ValueMember = "Id";

        //            if (comboBox3.Items.Count > 0)
        //                comboBox3.SelectedIndex = 0;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Ошибка загрузки врачей: " + ex.Message);
        //    }
        //}



        // Универсальный метод для загрузки врачей в ComboBox
        private void LoadDoctorsToComboBox(ComboBox comboBox, bool includeAllDoctors = false)
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string sql = "SELECT doctor_id, last_name || ' ' || first_name as full_name FROM myschema.doctors ORDER BY last_name";
                    var cmd = new NpgsqlCommand(sql, conn);
                    var reader = cmd.ExecuteReader();

                    comboBox.Items.Clear();

                    // Добавляем опцию "Все врачи" если нужно
                    if (includeAllDoctors)
                    {
                        comboBox.Items.Add(new
                        {
                            Id = 0,
                            Name = "Все врачи"
                        });
                    }

                    while (reader.Read())
                    {
                        comboBox.Items.Add(new
                        {
                            Id = reader.GetInt32(0),
                            Name = reader.GetString(1)
                        });
                    }
                    reader.Close();

                    comboBox.DisplayMember = "Name";
                    comboBox.ValueMember = "Id";

                    if (comboBox.Items.Count > 0)
                        comboBox.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки врачей: " + ex.Message);
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            //    string sql = @"
            //SELECT 
            //    p.last_name as ""Фамилия"",
            //    p.first_name as ""Имя"",
            //    p.patronymic as ""Отчество"",
            //    p.birth_date as ""Дата рождения"",
            //    v.visit_date_time as ""Дата визита"",
            //    COALESCE(d.mkb_code, 'Нет') as ""Код диагноза"",
            //    COALESCE(d.description, 'Нет диагноза') as ""Диагноз""
            //FROM myschema.visits v
            //JOIN myschema.schedule s ON v.schedule_id = s.schedule_id
            //JOIN myschema.patients p ON v.patient_id = p.patient_id
            //LEFT JOIN myschema.sick_leaves sl ON v.visit_id = sl.visit_id
            //LEFT JOIN myschema.diagnoses d ON sl.sick_leave_id = d.sick_leave_id
            //WHERE s.doctor_id = @id
            //  AND v.visit_date_time::date BETWEEN @from AND @to
            //ORDER BY v.visit_date_time";

            //    using (var conn = new NpgsqlConnection(connString))
            //    {
            //        conn.Open();
            //        var cmd = new NpgsqlCommand(sql, conn);
            //        cmd.Parameters.AddWithValue("@id", doctorId);
            //        cmd.Parameters.AddWithValue("@from", dateFrom);
            //        cmd.Parameters.AddWithValue("@to", dateTo);


            try
            {
                dynamic doctor = comboBox3.SelectedItem;
                int doctorId = doctor.Id;

                // Формируем SQL строку с явным приведением типов
                string sql = $@"
            SELECT * 
            FROM myschema.fn_doctor_patients_report(
                {doctorId}, 
                '{dateTimePicker3.Value:yyyy-MM-dd}'::date, 
                '{dateTimePicker4.Value:yyyy-MM-dd}'::date)";

                MessageBox.Show($"Выполняется:\n{sql}", "SQL запрос");

                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    var cmd = new NpgsqlCommand(sql, conn);
                    DataTable dt = new DataTable();
                    new NpgsqlDataAdapter(cmd).Fill(dt);
                    dataGridView2.DataSource = dt;
                    dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }

        }

        private DataTable allVisitsData;

        // Метод загрузки данных визитов
        void LoadVisitsData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    string sql = @"
                        SELECT 
                            v.schedule_id as ID,
                            d.last_name || ' ' || d.first_name as Врач,
                            p.last_name || ' ' || p.first_name as Пациент,
                            v.visit_date_time as ""Дата визита"",
                            v.status as Статус
                        FROM myschema.visits v
                        JOIN myschema.schedule s ON v.schedule_id = s.schedule_id
                        JOIN myschema.doctors d ON s.doctor_id = d.doctor_id
                        JOIN myschema.patients p ON v.patient_id = p.patient_id
                        ORDER BY v.visit_date_time DESC";

                    var adapter = new NpgsqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    allVisitsData = dt.Copy();
                    dataGridView3.DataSource = dt;
                    dataGridView3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    label8.Text = $"Всего визитов: {dt.Rows.Count}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки визитов: " + ex.Message);
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            // Показываем сообщение
            MessageBox.Show("Выберите свободный слот в расписании для записи пациента.");

            // Включаем режим выбора слота
            isSelectingSlotForVisit = true;
        }

        private void button19_Click(object sender, EventArgs e)
        {

            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    // Детальный запрос для выбранного врача (такой же как в LoadVisitsData, но с фильтром)
                    string sqlDetail = @"
                SELECT 
                    v.visit_id as ID,
                    d.last_name || ' ' || d.first_name as Врач,
                    p.last_name || ' ' || p.first_name as Пациент,
                    v.visit_date_time as ""Дата визита"",
                    v.status as Статус
                FROM myschema.visits v
                JOIN myschema.schedule s ON v.schedule_id = s.schedule_id
                JOIN myschema.doctors d ON s.doctor_id = d.doctor_id
                JOIN myschema.patients p ON v.patient_id = p.patient_id";

                    // Запрос для статистики
                    string sqlStats = @"
                SELECT 
                    COUNT(*) as Всего,
                    COUNT(CASE WHEN v.status = 'Запланирован' THEN 1 END) as Запланировано,
                    COUNT(CASE WHEN v.status = 'Осуществлен' THEN 1 END) as Осуществлено,
                    COUNT(CASE WHEN v.status = 'Отменен' THEN 1 END) as Отменено
                FROM myschema.visits v
                JOIN myschema.schedule s ON v.schedule_id = s.schedule_id
                JOIN myschema.doctors d ON s.doctor_id = d.doctor_id";

                    // Добавляем фильтр по врачу, если выбран не "Все врачи"
                    dynamic selectedDoctor = comboBox5.SelectedItem;
                    int doctorId = selectedDoctor.Id;

                    if (doctorId != 0)
                    {
                        sqlDetail += " WHERE d.doctor_id = @doctor_id";
                        sqlStats += " WHERE d.doctor_id = @doctor_id";
                    }

                    sqlDetail += " ORDER BY v.visit_date_time DESC";

                    var cmdDetail = new NpgsqlCommand(sqlDetail, conn);

                    if (doctorId != 0)
                    {
                        cmdDetail.Parameters.AddWithValue("@doctor_id", doctorId);
                    }

                    var adapter = new NpgsqlDataAdapter(cmdDetail);
                    DataTable dtDetail = new DataTable();
                    adapter.Fill(dtDetail);

                    dataGridView3.DataSource = dtDetail;
                    dataGridView3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    // Обновляем label8 (количество визитов)
                    label8.Text = $"Всего визитов: {dtDetail.Rows.Count}";

                    // Получаем статистику для label22
                    var cmdStats = new NpgsqlCommand(sqlStats, conn);

                    if (doctorId != 0)
                    {
                        cmdStats.Parameters.AddWithValue("@doctor_id", doctorId);
                    }

                    using (var reader = cmdStats.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            int totalVisits = reader.GetInt32(0);
                            int plannedVisits = reader.IsDBNull(1) ? 0 : reader.GetInt32(1);
                            int completedVisits = reader.IsDBNull(2) ? 0 : reader.GetInt32(2);
                            int cancelledVisits = reader.IsDBNull(3) ? 0 : reader.GetInt32(3);

                            // Выводим статистику в label22
                            label22.Text = $"Всего визитов: {totalVisits}\n" +
                                          $"Запланировано: {plannedVisits}\n" +
                                          $"Осуществлено: {completedVisits}\n" +
                                          $"Отменено: {cancelledVisits}";
                        }
                        else
                        {
                            label22.Text = "Нет данных для отображения";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка получения статистики: " + ex.Message);
            }
        }

        void LoadDoctorsData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    string sql = @"
                        SELECT 
                            doctor_id as ID,
                            last_name as Фамилия,
                            first_name as Имя,
                            patronymic as Отчество,
                            specialty as Специальность,
                            experience as Опыт,
                            birth_date as ""Дата рождения"",
                            address as Адрес
                        FROM myschema.doctors
                        ORDER BY last_name, first_name";

                    var adapter = new NpgsqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dataGridView5.DataSource = dt;
                    dataGridView5.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    label13.Text = $"Всего врачей: {dt.Rows.Count}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки врачей: " + ex.Message);
            }
        }

        void LoadPatientsData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    string sql = @"
                        SELECT 
                            patient_id as ID,
                            last_name as Фамилия,
                            first_name as Имя,
                            patronymic as Отчество,
                            birth_date as ""Дата рождения"",
                            address as Адрес
                        FROM myschema.patients
                        ORDER BY last_name, first_name";

                    var adapter = new NpgsqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dataGridView4.DataSource = dt;
                    dataGridView4.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    label12.Text = $"Всего пациентов: {dt.Rows.Count}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки пациентов: " + ex.Message);
            }
        }

        void LoadAdministratorsData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    string sql = @"
                        SELECT 
                            admin_id as ID,
                            last_name as Фамилия,
                            first_name as Имя,
                            patronymic as Отчество,
                            birth_date as ""Дата рождения"",
                            address as Адрес
                        FROM myschema.administrators
                        ORDER BY last_name, first_name";

                    var adapter = new NpgsqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dataGridView6.DataSource = dt;
                    dataGridView6.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    label14.Text = $"Всего администраторов: {dt.Rows.Count}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки администраторов: " + ex.Message);
            }
        }

        // Обработчик изменения выбора в комбобоксе
        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Показываем поля специальность и стаж только для врача
            if (comboBox4.SelectedItem.ToString() == "Врач")
            {
                textBox5.Visible = true;
                numericUpDown1.Visible = true;
            }
            else
            {
                textBox5.Visible = false;
                numericUpDown1.Visible = false;
            }
        }

        private void button28_Click(object sender, EventArgs e)
        {
            // Кнопка добавления нового пользователя
            string userType = comboBox4.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(userType))
            {
                MessageBox.Show("Выберите тип пользователя!");
                return;
            }

            // Проверка обязательных полей
            if (string.IsNullOrWhiteSpace(textBox1.Text) || // Фамилия
                string.IsNullOrWhiteSpace(textBox2.Text) || // Имя
                string.IsNullOrWhiteSpace(textBox4.Text))   // Адрес
            {
                MessageBox.Show("Заполните все обязательные поля!");
                return;
            }

            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string sql = "";

                    switch (userType)
                    {
                        case "Пациент":
                            sql = @"INSERT INTO myschema.patients 
                            (last_name, first_name, patronymic, birth_date, address) 
                            VALUES (@last_name, @first_name, @patronymic, @birth_date, @address)";
                            break;

                        case "Врач":
                            if (string.IsNullOrWhiteSpace(textBox5.Text))
                            {
                                MessageBox.Show("Для врача заполните специальность!");
                                return;
                            }

                            sql = @"INSERT INTO myschema.doctors 
                            (last_name, first_name, patronymic, specialty, experience, birth_date, address) 
                            VALUES (@last_name, @first_name, @patronymic, @specialty, @experience, @birth_date, @address)";
                            break;

                        case "Администратор":
                            sql = @"INSERT INTO myschema.administrators 
                            (last_name, first_name, patronymic, birth_date, address) 
                            VALUES (@last_name, @first_name, @patronymic, @birth_date, @address)";
                            break;

                        default:
                            MessageBox.Show("Неизвестный тип пользователя!");
                            return;
                    }

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        // Общие параметры
                        cmd.Parameters.AddWithValue("@last_name", textBox1.Text);
                        cmd.Parameters.AddWithValue("@first_name", textBox2.Text);
                        cmd.Parameters.AddWithValue("@patronymic",
                            string.IsNullOrWhiteSpace(textBox3.Text) ? (object)DBNull.Value : textBox3.Text);
                        cmd.Parameters.AddWithValue("@birth_date", dateTimePicker5.Value.Date);
                        cmd.Parameters.AddWithValue("@address", textBox4.Text);

                        // Дополнительные параметры для врача
                        if (userType == "Врач")
                        {
                            cmd.Parameters.AddWithValue("@specialty", textBox5.Text);
                            cmd.Parameters.AddWithValue("@experience", (int)numericUpDown1.Value);
                        }

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show($"{userType} успешно добавлен!");

                            // Очистка полей
                            textBox1.Clear();
                            textBox2.Clear();
                            textBox3.Clear();
                            textBox4.Clear();
                            textBox5.Clear();
                            numericUpDown1.Value = 0;
                            dateTimePicker5.Value = DateTime.Now;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка добавления: {ex.Message}");
            }
        }

        private void dataGridView4_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView4.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridView4.SelectedRows[0];

                // Заполняем поля данными пациента
                textBox1.Text = row.Cells["Фамилия"].Value.ToString();
                textBox2.Text = row.Cells["Имя"].Value.ToString();
                textBox3.Text = row.Cells["Отчество"].Value?.ToString() ?? "";
                textBox4.Text = row.Cells["Адрес"].Value.ToString();
                dateTimePicker5.Value = Convert.ToDateTime(row.Cells["Дата рождения"].Value);

                // Устанавливаем тип пользователя
                comboBox4.SelectedItem = "Пациент";

                // Очищаем поля для врача (если они видимы)
                textBox5.Clear();
                numericUpDown1.Value = 0;
            }
        }

        private void dataGridView5_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView5.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridView5.SelectedRows[0];

                // Заполняем поля данными врача
                textBox1.Text = row.Cells["Фамилия"].Value.ToString();
                textBox2.Text = row.Cells["Имя"].Value.ToString();
                textBox3.Text = row.Cells["Отчество"].Value?.ToString() ?? "";
                textBox4.Text = row.Cells["Адрес"].Value.ToString();
                dateTimePicker5.Value = Convert.ToDateTime(row.Cells["Дата рождения"].Value);
                textBox5.Text = row.Cells["Специальность"].Value.ToString();
                numericUpDown1.Value = Convert.ToDecimal(row.Cells["Опыт"].Value);

                // Устанавливаем тип пользователя
                comboBox4.SelectedItem = "Врач";
            }
        }

        private void dataGridView6_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView6.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridView6.SelectedRows[0];

                // Заполняем поля данными администратора
                textBox1.Text = row.Cells["Фамилия"].Value.ToString();
                textBox2.Text = row.Cells["Имя"].Value.ToString();
                textBox3.Text = row.Cells["Отчество"].Value?.ToString() ?? "";
                textBox4.Text = row.Cells["Адрес"].Value.ToString();
                dateTimePicker5.Value = Convert.ToDateTime(row.Cells["Дата рождения"].Value);

                // Устанавливаем тип пользователя
                comboBox4.SelectedItem = "Администратор";

                // Очищаем поля для врача (если они видимы)
                textBox5.Clear();
                numericUpDown1.Value = 0;
            }
        }

        private void button29_Click(object sender, EventArgs e)
        {
            // Определяем, в какой таблице выбрана строка и получаем ID
            int selectedId = -1;
            string userType = "";

            // Проверяем, в какой таблице выбрана запись
            if (dataGridView4.SelectedRows.Count > 0)
            {
                selectedId = Convert.ToInt32(dataGridView4.SelectedRows[0].Cells["ID"].Value);
                userType = "Пациент";
            }
            else if (dataGridView5.SelectedRows.Count > 0)
            {
                selectedId = Convert.ToInt32(dataGridView5.SelectedRows[0].Cells["ID"].Value);
                userType = "Врач";
            }
            else if (dataGridView6.SelectedRows.Count > 0)
            {
                selectedId = Convert.ToInt32(dataGridView6.SelectedRows[0].Cells["ID"].Value);
                userType = "Администратор";
            }
            else
            {
                MessageBox.Show("Выберите запись для редактирования");
                return;
            }

            // Проверяем, что форма заполнена данными
            if (string.IsNullOrWhiteSpace(textBox1.Text) || // Фамилия
                string.IsNullOrWhiteSpace(textBox2.Text) || // Имя
                string.IsNullOrWhiteSpace(textBox4.Text))   // Адрес
            {
                MessageBox.Show("Заполните все обязательные поля!");
                return;
            }

            // Проверяем, что тип в комбобоксе совпадает с выбранной записью
            string selectedUserType = comboBox4.SelectedItem?.ToString();
            if (selectedUserType != userType)
            {
                MessageBox.Show($"Тип пользователя в форме ({selectedUserType}) не соответствует выбранной записи ({userType}). Измените тип в комбобоксе.");
                return;
            }

            UpdateUser(userType, selectedId);
        }

        // Метод для обновления пользователя
        private void UpdateUser(string userType, int id)
        {
            // Проверка обязательных полей
            if (string.IsNullOrWhiteSpace(textBox1.Text) || // Фамилия
                string.IsNullOrWhiteSpace(textBox2.Text) || // Имя
                string.IsNullOrWhiteSpace(textBox4.Text))   // Адрес
            {
                MessageBox.Show("Заполните все обязательные поля!");
                return;
            }

            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string sql = "";

                    switch (userType)
                    {
                        case "Пациент":
                            sql = @"UPDATE myschema.patients 
                    SET last_name = @last_name, 
                        first_name = @first_name, 
                        patronymic = @patronymic, 
                        birth_date = @birth_date, 
                        address = @address 
                    WHERE patient_id = @id";
                            break;

                        case "Врач":
                            if (string.IsNullOrWhiteSpace(textBox5.Text))
                            {
                                MessageBox.Show("Для врача заполните специальность!");
                                return;
                            }

                            sql = @"UPDATE myschema.doctors 
                    SET last_name = @last_name, 
                        first_name = @first_name, 
                        patronymic = @patronymic, 
                        specialty = @specialty, 
                        experience = @experience, 
                        birth_date = @birth_date, 
                        address = @address 
                    WHERE doctor_id = @id";
                            break;

                        case "Администратор":
                            sql = @"UPDATE myschema.administrators 
                    SET last_name = @last_name, 
                        first_name = @first_name, 
                        patronymic = @patronymic, 
                        birth_date = @birth_date, 
                        address = @address 
                    WHERE admin_id = @id";
                            break;
                    }

                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        // Общие параметры
                        cmd.Parameters.AddWithValue("@last_name", textBox1.Text);
                        cmd.Parameters.AddWithValue("@first_name", textBox2.Text);
                        cmd.Parameters.AddWithValue("@patronymic",
                            string.IsNullOrWhiteSpace(textBox3.Text) ? (object)DBNull.Value : textBox3.Text);
                        cmd.Parameters.AddWithValue("@birth_date", dateTimePicker5.Value.Date);
                        cmd.Parameters.AddWithValue("@address", textBox4.Text);
                        cmd.Parameters.AddWithValue("@id", id);

                        // Дополнительные параметры для врача
                        if (userType == "Врач")
                        {
                            cmd.Parameters.AddWithValue("@specialty", textBox5.Text);
                            cmd.Parameters.AddWithValue("@experience", (int)numericUpDown1.Value);
                        }

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show($"{userType} успешно обновлен!");

                            // Обновляем таблицы напрямую
                            LoadDoctorsData();
                            LoadPatientsData();
                            LoadAdministratorsData();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обновления: {ex.Message}");
            }
        }

        //обновить
        private void button30_Click(object sender, EventArgs e)
        {
            LoadDoctorsData();
            LoadPatientsData();
            LoadAdministratorsData();
            MessageBox.Show("Таблицы обновлены!");
        }

        //удалить
        private void button31_Click(object sender, EventArgs e)
        {
            // Определяем, в какой таблице выбрана строка
            int selectedId = -1;
            string userType = "";
            string displayName = "";
            DataGridViewRow selectedRow = null;

            if (dataGridView4.SelectedRows.Count > 0)
            {
                selectedRow = dataGridView4.SelectedRows[0];
                selectedId = Convert.ToInt32(selectedRow.Cells["ID"].Value);
                userType = "Пациент";
                displayName = $"{selectedRow.Cells["Фамилия"].Value} {selectedRow.Cells["Имя"].Value}";
            }
            else if (dataGridView5.SelectedRows.Count > 0)
            {
                selectedRow = dataGridView5.SelectedRows[0];
                selectedId = Convert.ToInt32(selectedRow.Cells["ID"].Value);
                userType = "Врач";
                displayName = $"{selectedRow.Cells["Фамилия"].Value} {selectedRow.Cells["Имя"].Value}";
            }
            else if (dataGridView6.SelectedRows.Count > 0)
            {
                selectedRow = dataGridView6.SelectedRows[0];
                selectedId = Convert.ToInt32(selectedRow.Cells["ID"].Value);
                userType = "Администратор";
                displayName = $"{selectedRow.Cells["Фамилия"].Value} {selectedRow.Cells["Имя"].Value}";
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления", "Информация",
                               MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Проверяем, не пытаемся ли удалить уже "удаленного" (000) пользователя
            string firstName = selectedRow.Cells["Имя"].Value?.ToString() ?? "";
            string lastName = selectedRow.Cells["Фамилия"].Value?.ToString() ?? "";

            if (firstName == "000" && lastName == "000")
            {
                MessageBox.Show("Эта запись уже была удалена (данные заменены на 000).", "Информация",
                               MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Подтверждение удаления
            DialogResult result = MessageBox.Show(
                $"Вы уверены, что хотите удалить {userType.ToLower()}:\n" +
                $"{displayName} (ID: {selectedId})?\n\n" +
                "Если есть связанные записи, данные будут заменены на '000'.",
                "Подтверждение удаления",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result != DialogResult.Yes)
                return;

            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    string deleteSql = "";
                    string checkSql = "";
                    string checkColumn = "";

                    // Выбираем SQL в зависимости от типа пользователя
                    switch (userType)
                    {
                        case "Пациент":
                            deleteSql = "DELETE FROM myschema.patients WHERE patient_id = @id";
                            checkSql = "SELECT first_name, last_name FROM myschema.patients WHERE patient_id = @id";
                            checkColumn = "first_name";
                            break;
                        case "Врач":
                            deleteSql = "DELETE FROM myschema.doctors WHERE doctor_id = @id";
                            checkSql = "SELECT first_name, last_name FROM myschema.doctors WHERE doctor_id = @id";
                            checkColumn = "first_name";
                            break;
                        case "Администратор":
                            deleteSql = "DELETE FROM myschema.administrators WHERE admin_id = @id";
                            checkSql = "SELECT first_name, last_name FROM myschema.administrators WHERE admin_id = @id";
                            checkColumn = "first_name";
                            break;
                    }

                    int rowsAffected = 0;

                    // Выполняем удаление
                    using (var deleteCmd = new NpgsqlCommand(deleteSql, conn))
                    {
                        deleteCmd.Parameters.AddWithValue("@id", selectedId);
                        rowsAffected = deleteCmd.ExecuteNonQuery();
                    }

                    // Анализируем результат
                    string message = "";
                    bool isSuccess = false;

                    if (rowsAffected == 1)
                    {
                        // Запись удалена полностью
                        message = $"{userType} '{displayName}' успешно удален полностью!";
                        isSuccess = true;
                    }
                    else // rowsAffected == 0 - значит сработал триггер
                    {
                        // Проверяем, что осталось в базе
                        using (var checkCmd = new NpgsqlCommand(checkSql, conn))
                        {
                            checkCmd.Parameters.AddWithValue("@id", selectedId);
                            using (var reader = checkCmd.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    string newFirstName = reader["first_name"]?.ToString() ?? "";
                                    string newLastName = reader["last_name"]?.ToString() ?? "";

                                    if (newFirstName == "000" && newLastName == "000")
                                    {
                                        message = $"{userType} '{displayName}' не может быть удален,\n" +
                                                 "так как есть связанные записи.\n" +
                                                 "Данные заменены на '000'.";
                                        isSuccess = true; // Все прошло как задумано
                                    }
                                    else
                                    {
                                        message = $"{userType} не был удален и данные не изменены.\n" +
                                                 "Возможно, запись уже была изменена.";
                                    }
                                }
                                else
                                {
                                    // Запись не найдена - возможно, ее кто-то удалил параллельно
                                    message = $"{userType} не найден в базе данных.";
                                    isSuccess = true;
                                }
                            }
                        }
                    }

                    // Показываем результат
                    MessageBox.Show(message, isSuccess ? "Информация" : "Внимание",
                                  MessageBoxButtons.OK,
                                  isSuccess ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

                    // Обновляем таблицы
                    LoadDoctorsData();
                    LoadPatientsData();
                    LoadAdministratorsData();

                    // Очищаем поля формы
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    textBox5.Clear();
                    numericUpDown1.Value = 0;
                    dateTimePicker5.Value = DateTime.Now;
                }
            }
            catch (PostgresException ex)
            {
                // Обработка ошибок PostgreSQL
                string errorMessage = $"Ошибка PostgreSQL: {ex.MessageText}\n";

                if (ex.SqlState == "23503") // Ошибка внешнего ключа
                {
                    errorMessage += "Не удалось выполнить операцию из-за ограничений внешних ключей.\n" +
                                   "Возможно, есть другие связанные записи, которые не обрабатываются триггерами.";
                }

                MessageBox.Show(errorMessage, "Ошибка базы данных",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        //////////////////////////
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (isSelectingSlotForVisit && e.RowIndex >= 0)
            {
                try
                {
                    DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                    // Проверяем, что слот свободен
                    string status = selectedRow.Cells["Статус"].Value.ToString();

                    if (status != "Свободен")
                    {
                        MessageBox.Show("Выбранный слот занят! Выберите свободный слот.");
                        return;
                    }

                    // Получаем данные из выбранной строки
                    selectedScheduleId = Convert.ToInt32(selectedRow.Cells["ID"].Value);
                    selectedDoctorName = selectedRow.Cells["Врач"].Value.ToString();
                    selectedWorkDate = Convert.ToDateTime(selectedRow.Cells["Дата"].Value);
                    selectedTime = TimeSpan.Parse(selectedRow.Cells["Время"].Value.ToString());

                    // Получаем doctor_id из базы данных
                    using (var conn = new NpgsqlConnection(connString))
                    {
                        conn.Open();
                        string sql = "SELECT doctor_id FROM myschema.schedule WHERE schedule_id = @schedule_id";
                        var cmd = new NpgsqlCommand(sql, conn);
                        cmd.Parameters.AddWithValue("@schedule_id", selectedScheduleId);
                        var result = cmd.ExecuteScalar();
                        selectedDoctorIdFromSchedule = result != null ? Convert.ToInt32(result) : -1;
                    }

                    // Открываем Form4
                    Form4 form4 = new Form4(selectedDoctorName, selectedWorkDate, selectedTime, connString);

                    if (form4.ShowDialog() == DialogResult.OK)
                    {
                        // Вызываем процедуру book_appointment
                        int patientId = form4.SelectedPatientId;

                        if (patientId > 0)
                        {
                            CallBookAppointment(patientId);
                        }
                    }

                    // Сбрасываем флаг
                    isSelectingSlotForVisit = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                    isSelectingSlotForVisit = false;
                }
            }
        }

        // Метод для вызова процедуры book_appointment
        private void CallBookAppointment(int patientId)
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    // Вызываем процедуру book_appointment
                    using (var cmd = new NpgsqlCommand("CALL myschema.book_appointment(@p_patient_id, @p_doctor_id, @p_desired_date, @p_desired_time)", conn))
                    {
                        // Явно указываем типы параметров
                        cmd.Parameters.Add("@p_patient_id", NpgsqlDbType.Integer).Value = patientId;
                        cmd.Parameters.Add("@p_doctor_id", NpgsqlDbType.Integer).Value = selectedDoctorIdFromSchedule;
                        cmd.Parameters.Add("@p_desired_date", NpgsqlDbType.Date).Value = selectedWorkDate.Date;
                        cmd.Parameters.Add("@p_desired_time", NpgsqlDbType.Time).Value = selectedTime;

                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Визит успешно добавлен!");

                    // Обновляем данные
                    LoadData();
                    LoadVisitsData();
                }
            }
            catch (PostgresException ex)
            {
                if (ex.SqlState == "P0001") // RAISE EXCEPTION в процедуре
                {
                    MessageBox.Show("Ошибка: " + ex.MessageText);
                }
                else
                {
                    MessageBox.Show("Ошибка базы данных: " + ex.MessageText);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }


        ////////
        void LoadDiagnosesStatistics()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    // SQL запрос для получения количества случаев по каждому диагнозу
                    string sql = @"
                SELECT 
                    d.mkb_code as ""Код МКБ"",
                    d.description as ""Описание диагноза"",
                    COUNT(d.diagnosis_id) as ""Количество случаев"",
                    STRING_AGG(DISTINCT sl.issue_date::text, ', ') as ""Даты выдачи"",
                    COUNT(DISTINCT sl.patient_id) as ""Количество пациентов""
                FROM myschema.diagnoses d
                LEFT JOIN myschema.sick_leaves sl ON d.sick_leave_id = sl.sick_leave_id
                GROUP BY d.mkb_code, d.description
                ORDER BY ""Количество случаев"" DESC, ""Код МКБ""";

                    var adapter = new NpgsqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dataGridView7.DataSource = dt;
                    dataGridView7.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                    // Добавляем подсказку для отображения всех дат
                    foreach (DataGridViewRow row in dataGridView7.Rows)
                    {
                        if (row.Cells["Даты выдачи"].Value != null)
                        {
                            string dates = row.Cells["Даты выдачи"].Value.ToString();
                            if (dates.Length > 50)
                            {
                                row.Cells["Даты выдачи"].ToolTipText = dates;
                            }
                        }
                    }

                    if (label24 != null)
                    {
                        string countSql = "SELECT COUNT(DISTINCT mkb_code) FROM myschema.diagnoses";
                        var countCmd = new NpgsqlCommand(countSql, conn);
                        int diagnosisCount = Convert.ToInt32(countCmd.ExecuteScalar());
                        label24.Text = $"Всего диагнозов: {diagnosisCount}";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки статистики диагнозов: " + ex.Message);
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            LoadDiagnosesStatistics();
            MessageBox.Show("Статистика диагнозов обновлена", "Информация",
                           MessageBoxButtons.OK, MessageBoxIcon.Information);
        }



    }
   
}
