﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POLICLINICA
{
    public partial class Form7 : Form
    {
        private int sickLeaveId;
        private string connectionString;

        public Form7()
        {
            InitializeComponent();
        }
        
        // Конструктор с параметрами
        public Form7(int sickLeaveId, string patientName, string connectionString) : this()
        {
            this.sickLeaveId = sickLeaveId;
            this.connectionString = connectionString;

            // Отображаем информацию о пациенте
            label1.Text = $"Пациент: {patientName}";
        }

        // Кнопка "Добавить"
        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Введите код МКБ!", "Ошибка");
                return;
            }

            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Введите описание диагноза!", "Ошибка");
                return;
            }

            try
            {
                AddDiagnosisToDatabase();
                MessageBox.Show("Диагноз успешно добавлен!", "Успех");
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении: " + ex.Message, "Ошибка");
            }
        }

        // Кнопка "Отмена"
        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void AddDiagnosisToDatabase()
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();

                string insertSql = @"
                    INSERT INTO myschema.diagnoses 
                        (sick_leave_id, mkb_code, description)
                    VALUES 
                        (@sick_leave_id, @mkb_code, @description)";

                using (var cmd = new NpgsqlCommand(insertSql, conn))
                {
                    cmd.Parameters.AddWithValue("@sick_leave_id", sickLeaveId);
                    cmd.Parameters.AddWithValue("@mkb_code", textBox1.Text);
                    cmd.Parameters.AddWithValue("@description", textBox2.Text);

                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
