﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POLICLINICA
{
    public partial class Form1 : Form
    {
        string connString = "Host=localhost;Database=polyclinic;Username=postgres;Password=1234;";
        private DataTable allData;

        public Form1()
        {
            InitializeComponent();
            LoadData();
            LoadDoctorsToGrid2();
            LoadAllPhotos();
        }

        //  метод загрузки
        void LoadData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();

                    string sql = @"
                        SELECT 
                            s.schedule_id as ID,
                            d.last_name || ' ' || d.first_name as Врач,
                            s.work_date as Дата,
                            s.time as Время
                        FROM myschema.schedule s
                        JOIN myschema.doctors d ON s.doctor_id = d.doctor_id
                        WHERE s.is_available = true
                        ORDER BY Врач, Дата, Время";

                    var adapter = new NpgsqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    // Сохраняем данные для фильтрации
                    allData = dt.Copy();

                    // Показываем в таблице
                    dataGridView1.DataSource = dt;
                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (allData != null)
            {
                dataGridView1.DataSource = allData;
            }
        }
        
        // Врачи

        private void button2_Click(object sender, EventArgs e)
        {
            FilterData("Быков Андрей");
        }
        
        private void button3_Click(object sender, EventArgs e)
        {
            FilterData("Ерошкина Анна");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FilterData("Смирнова Ольга");
        }
        
         private void button5_Click(object sender, EventArgs e)
        {
            FilterData("Смирнов Ярослав");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FilterData("Кузнецов Андрей");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            FilterData("Петрова Мария");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            FilterData("Лобанов Семён");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            FilterData("Елисеева Марианна");
        }
        private void button10_Click(object sender, EventArgs e)
        {
            FilterData("Романова Антонина");
        }

        // Метод фильтрации
        private void FilterData(string doctorName)
        {
            if (allData == null)
            {
                MessageBox.Show("Нет данных для фильтрации");
                return;
            }

            try
            {
                // Создаем новую таблицу
                DataTable filtered = new DataTable();
                filtered = allData.Clone(); // Копируем структуру

                int count = 0;
                foreach (DataRow row in allData.Rows)
                {
                    if (row["Врач"].ToString() == doctorName)
                    {
                        filtered.ImportRow(row);
                        count++;
                    }
                }

                dataGridView1.DataSource = filtered;

                MessageBox.Show($"Найдено {count} записей для {doctorName}");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка фильтрации: " + ex.Message);
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog(); // Форма открывается как модальное окно
        }

        // Метод загрузки врачей
        private void LoadDoctorsToGrid2()
        {
            string query = @"
        SELECT 
            doctor_id as ID,
            last_name as Фамилия,
            first_name as Имя,
            patronymic as Отчество,
            specialty as Специальность,
            experience as Стаж,
            birth_date as Дата_рождения
        FROM myschema.doctors";

            using (var conn = new NpgsqlConnection(connString))
            {
                conn.Open();

                using (var adapter = new NpgsqlDataAdapter(query, conn))
                {
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    dataGridView2.DataSource = table;
                }
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LoadAllPhotos()
        {
            // Настраиваем отображение
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;

            // Для каждого врача - отдельный запрос
            pictureBox1.Image = GetPhotoById(1);
            pictureBox2.Image = GetPhotoById(2);
            pictureBox3.Image = GetPhotoById(3);
            pictureBox4.Image = GetPhotoById(4);
            pictureBox5.Image = GetPhotoById(7);
            pictureBox6.Image = GetPhotoById(8);
        }

        private Image GetPhotoById(int id)
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    var cmd = new NpgsqlCommand(
                        $"SELECT image_data FROM myschema.doctor_images WHERE doctor_id = {id}",
                        conn);

                    byte[] data = (byte[])cmd.ExecuteScalar();
                    return Image.FromStream(new System.IO.MemoryStream(data));
                }
            }
            catch
            {
                return null; // Просто возвращаем null при ошибке
            }
        }
    }
}